package com.path.atm.bo.teller.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.path.atm.bo.common.ATMCommonConstants;
import com.path.atm.bo.common.ATMCommonUtil;
import com.path.atm.bo.teller.TellerBO;
import com.path.atm.dao.acquirer.AcquirerDAO;
import com.path.atm.vo.teller.TellerCO;
import com.path.atm.vo.teller.TellerSC;
import com.path.bo.common.ConstantsCommon;
import com.path.lib.common.base.BaseBO;
import com.path.lib.common.util.PathPropertyUtil;

/**
 * 
 * Copyright 2019, Path Solutions
 * Path Solutions retains all ownership rights to this source code 
 * 
 * @author: Alim Khowaja
 *
 * TellerBOImpl.java used to
 */
public class TellerBOImpl extends BaseBO implements TellerBO
{
    private AcquirerDAO acquirerDAO;

    @Override
    public List returnTellerList(TellerSC tellerSC) throws Exception
    {
	//return service rmi property file
	String serviceRmi = ATMCommonUtil.returnRmiUrlByApplication(ATMCommonConstants.APP_NAME_RET);
	
	//fill parameter
	HashMap<String, Object> rmiObjectInputParamMap = fillObjInputParam(tellerSC);
	
	//send RMI call
	HashMap<String, Object> responseMap  = ATMCommonUtil.sendRMICall(serviceRmi, ATMCommonConstants.TELLER_BO_WEB_SERVICE_NAME, ATMCommonConstants.TELLER_BO_LIST_METHOD_NAME, rmiObjectInputParamMap);
	
	//retrieve list from map recieve from rmi response
	List<HashMap<String, Object>> tellersList = (List<HashMap<String, Object>>) responseMap.get("tellersList");

	List<TellerCO> tellerCOs = new ArrayList<TellerCO>();
	if(tellersList != null)
	{
	    for(HashMap<String, Object> hashMap : tellersList)
	    {
		TellerCO tellerCO = (TellerCO) PathPropertyUtil.convertToObject(hashMap, TellerCO.class);
		
		tellerCO.setTellerCode(new BigDecimal((String)hashMap.get("userCode")));
		tellerCO.setCompanyCode(new BigDecimal((String)responseMap.get("companyCode")));
		tellerCO.setBranchCode(new BigDecimal((String)responseMap.get("branchCode")));
		//tellerCO.setTellerType((String)hashMap.get("usertype"));
		tellerCOs.add(tellerCO);
	    }
	}
	return tellerCOs;
    }

    @Override
    public TellerCO returnTellerDetailsByCode(TellerSC tellerSC) throws Exception
    {
	//return service rmi property file
	String serviceRmi = ATMCommonUtil.returnRmiUrlByApplication(ATMCommonConstants.APP_NAME_RET);
		
	// fill parameters
	HashMap<String, Object> rmiObjectInputParamMap = fillObjInputParam(tellerSC);
	rmiObjectInputParamMap.put("userCode", tellerSC.getTellerCode());

	//send RMI call
	HashMap<String, Object> responseMap  = ATMCommonUtil.sendRMICall(serviceRmi, ATMCommonConstants.TELLER_BO_WEB_SERVICE_NAME, 
		ATMCommonConstants.TELLER_BO_DETAIL_METHOD_NAME, rmiObjectInputParamMap);
	
	TellerCO tellerCO = (TellerCO) PathPropertyUtil.convertToObject(responseMap, TellerCO.class);
	tellerCO.setTellerCode(new BigDecimal((String) responseMap.get("userCode")));
	return tellerCO;
    }

    /**
     * fill input parameters
     * @param tellerSC
     * @return
     */
    private HashMap<String, Object> fillObjInputParam(TellerSC tellerSC)
    {
	HashMap<String, Object> rmiObjectInputParamMap = new HashMap<String, Object>();

	rmiObjectInputParamMap.put("branchCode", tellerSC.getBranchCode());
	rmiObjectInputParamMap.put("companyCode", tellerSC.getCompCode());
	rmiObjectInputParamMap.put("language", tellerSC.getPreferredLanguage());
	
	rmiObjectInputParamMap.put("pagination.pageNumber", tellerSC.getPageNumber());
	rmiObjectInputParamMap.put("pagination.pageSize", tellerSC.getNbRec());
	
	if(tellerSC.getPageNumber()  != null && tellerSC.getPageNumber()>1)
	{
	    rmiObjectInputParamMap.put("pagination.totalCount", tellerSC.getRecords());
	}
	else
	{
	    rmiObjectInputParamMap.put("pagination.totalCount", ConstantsCommon.EMPTY_BIGDECIMAL_VALUE);
	}
	return rmiObjectInputParamMap;
    }

    public AcquirerDAO getAcquirerDAO()
    {
	return acquirerDAO;
    }

    public void setAcquirerDAO(AcquirerDAO acquirerDAO)
    {
	this.acquirerDAO = acquirerDAO;
    }
}
