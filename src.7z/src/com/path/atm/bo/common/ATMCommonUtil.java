/**
 * 
 */
package com.path.atm.bo.common;

import java.util.HashMap;
import com.path.bo.common.MessageCodes;
import com.path.bo.common.WebServiceCommonBO;
import com.path.lib.common.exception.BOException;
import com.path.lib.common.exception.BaseException;
import com.path.lib.common.util.PathPropertyUtil;
import com.path.lib.common.util.StringUtil;
import com.path.lib.remote.RmiServiceCaller;

/**
 * 
 * Copyright 2019, Path Solutions
 * Path Solutions retains all ownership rights to this source code 
 * 
 * @author: Alim Khowaja
 *
 * ATMCommonUtil.java used to
 */
public class ATMCommonUtil
{
    /*
     * validate Email Address
     */
    public static void validateEmail(String email) throws BaseException
    {

	if(StringUtil.isNotEmpty(email))
	{
	    int indexOfAt, indexOfDot, indexOfSpace;
	    indexOfAt = email.indexOf("@");
	    indexOfDot = email.indexOf(".");
	    indexOfSpace = email.indexOf(" ");
	    if(indexOfDot <= 0 || indexOfAt <= 0)
	    {
		throw new BOException(MessageCodes.PLEASE_ENTER_A_VALID_EMAIL_ADDR);
	    }
	    else if(indexOfSpace != 0 && indexOfSpace != -1)
	    {
		throw new BOException(MessageCodes.THE_EMAIL_ADDR_CAN_NOT_CONTAIN_SPACES);

	    }
	}

    }
    
    /**
     * 
     * @return
     */
    public static String returnRmiUrlByApplication(String appName)
    {
	
	String rmiUrl = null;
	try
	{
	    if(StringUtil.nullToEmpty(appName).equalsIgnoreCase(ATMCommonConstants.APP_NAME_GTW))
	    {
		rmiUrl = PathPropertyUtil.returnPathPropertyFromFile(ATMCommonConstants.GTW_SERVICE_REMOTING, ATMCommonConstants.GTW_SERVICE_URL);
	    }
	    else
		if(StringUtil.nullToEmpty(appName).equalsIgnoreCase(ATMCommonConstants.APP_NAME_RET))
		{
		    rmiUrl = PathPropertyUtil.returnPathPropertyFromFile(ATMCommonConstants.RET_SERVICE_REMOTING, ATMCommonConstants.RET_SERVICE_URL);
		}
	    rmiUrl = (rmiUrl == null) ? "" : rmiUrl;
	}
	catch(Exception e)
	{
	    e.printStackTrace();
	}
	return rmiUrl;
    }
    
    /**
     * send RMI Call
     * @param serviceRmi
     * @param boWebServiceName
     * @param methodName
     * @param rmiObjectInputParamMap
     * @return
     */
    public static HashMap<String, Object> sendRMICall(String serviceRmi, String boWebServiceName, String methodName, HashMap<String, Object> rmiObjectInputParamMap)
    {
	HashMap<String, Object> responseMap = new HashMap<String, Object>();	
	WebServiceCommonBO rmiCallerBO = null;
	try
	{
	    //return RMI interface
	    rmiCallerBO = (WebServiceCommonBO) RmiServiceCaller.returnRmiInterface(serviceRmi, WebServiceCommonBO.class,"webServiceCommonBOService");
	   
	    //call the method through RMI
	    responseMap = rmiCallerBO.executeWebServiceBoMethod(boWebServiceName, methodName,rmiObjectInputParamMap);
	}
	catch(Exception e)
	{
	    e.printStackTrace();
	}
	return responseMap;
    }
}