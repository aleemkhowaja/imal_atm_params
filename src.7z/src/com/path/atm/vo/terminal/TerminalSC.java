package com.path.atm.vo.terminal;

import java.math.BigDecimal;

import com.path.atm.vo.common.ATMBaseSC;

/**
 * 
 * Copyright 2019, Path Solutions
 * Path Solutions retains all ownership rights to this source code 
 * 
 * @author: Alim Khowaja
 *
 * TerminalSC.java used to
 */
public class TerminalSC extends ATMBaseSC
{
    private BigDecimal terminalId;
    private String terminalCode;

    public BigDecimal getTerminalId()
    {
	return terminalId;
    }

    public void setTerminalId(BigDecimal terminalId)
    {
	this.terminalId = terminalId;
    }

    public String getTerminalCode()
    {
	return terminalCode;
    }

    public void setTerminalCode(String terminalCode)
    {
	this.terminalCode = terminalCode;
    }

}