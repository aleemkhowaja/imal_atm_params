package com.path.atm.actions.lookups.interfaces;

import com.path.atm.bo.atminterface.AtmInterfaceBO;
import com.path.atm.bo.atminterface.AtmInterfaceConstants;
import com.path.atm.bo.common.ATMCommonConstants;
import com.path.atm.vo.atminterface.AtmInterfaceCO;
import com.path.atm.vo.atminterface.AtmInterfaceSC;
import com.path.struts2.lib.common.base.LookupBaseAction;
import com.path.vo.common.SessionCO;

/**
 * 
 * Copyright 2019, Path Solutions
 * Path Solutions retains all ownership rights to this source code 
 * 
 * @author: Alim Khowaja
 *
 * ATMInterfacesLookupDependancyAction.java used to
 */
public class ATMInterfacesLookupDependancyAction extends LookupBaseAction
{

    private AtmInterfaceSC atmInterfaceSC;
    private AtmInterfaceCO atmInterfaceCO;
    private AtmInterfaceBO atmInterfaceBO;
    

    /**
     * Construct vault Lookup based on the VO returned in the resultMap.
     * 
     * @return
     */
    public String returnATMInterfaceDetails()
    {
	try
	{
	    SessionCO sessionCO = returnSessionObject();
	    atmInterfaceSC.setCompCode(sessionCO.getCompanyCode());
	    atmInterfaceSC.setCurrAppName(sessionCO.getCurrentAppName());
	    atmInterfaceSC.setPreferredLanguage(sessionCO.getLanguage());
	    atmInterfaceSC.setInterfaceTypeLovId(AtmInterfaceConstants.INTERFACE_TYPE);
	    atmInterfaceSC.setLovTypeId(ATMCommonConstants.COMMON_STATUS_LOV);
	    atmInterfaceSC.setCrudMode(getIv_crud());
	    atmInterfaceSC.setPageRef(get_pageRef());
	    atmInterfaceSC.setStatus(ATMCommonConstants.STATUS_APPROVED);
	    
	    
	    // return Dependancy by interface Code
	    atmInterfaceCO = atmInterfaceBO.returnInterfaceById(atmInterfaceSC);

	}
	catch(Exception e)
	{
	    e.printStackTrace();
	    handleException(e, null, null);
	}
	return SUCCESS;
    }

    @Override
    public Object getModel()
    {
	return atmInterfaceSC;
    }

    public AtmInterfaceSC getAtmInterfaceSC()
    {
        return atmInterfaceSC;
    }

    public void setAtmInterfaceSC(AtmInterfaceSC atmInterfaceSC)
    {
        this.atmInterfaceSC = atmInterfaceSC;
    }

    public AtmInterfaceCO getAtmInterfaceCO()
    {
        return atmInterfaceCO;
    }

    public void setAtmInterfaceCO(AtmInterfaceCO atmInterfaceCO)
    {
        this.atmInterfaceCO = atmInterfaceCO;
    }

    public void setAtmInterfaceBO(AtmInterfaceBO atmInterfaceBO)
    {
        this.atmInterfaceBO = atmInterfaceBO;
    }

}
