package com.path.atm.actions.lookups.interfaces;

import java.util.List;
import com.path.atm.bo.atminterface.AtmInterfaceBO;
import com.path.atm.bo.atminterface.AtmInterfaceConstants;
import com.path.atm.bo.common.ATMCommonConstants;
import com.path.atm.vo.atminterface.AtmInterfaceCO;
import com.path.atm.vo.atminterface.AtmInterfaceSC;
import com.path.lib.vo.LookupGrid;
import com.path.struts2.lib.common.base.LookupBaseAction;
import com.path.vo.common.SessionCO;

public class ATMInterfacesLookupAction extends LookupBaseAction
{

   private AtmInterfaceSC atmInterfaceSC = new AtmInterfaceSC();
   private AtmInterfaceBO atmInterfaceBO;

    /**
     * Construct vault Lookup based on the VO returned in the resultMap.
     * 	
     * @return
     */
    public String constructLookup()
    {

	try
	{
	    // Design the Grid by defining the column model and column names
	    String[] name = { "iso_INTERFACESVO.INTERFACE_CODE", "iso_INTERFACESVO.COMP_CODE", 
		    "iso_INTERFACESVO.DESCRIPTION" , "iso_INTERFACESVO.INTERFACE_TYPE"};
	    String[] colType = { "text", "text", "text", "text"};
	    String[] titles = { getText("code_key"), getText("comp_code_key"), getText("Description_key"), getText("interface_type_key")};

	    // Defining the Grid
	    LookupGrid grid = new LookupGrid();
	    grid.setCaption(getText("atminterfaces"));
	    grid.setRowNum("5");
	    grid.setUrl("/path/atm/common/lookups/ATMInterfacesLookupAction_populateATMInterfacesLookup");
	    lookup(grid, atmInterfaceSC, name, colType, titles);
	}
	catch(Exception e)
	{
	    handleException(e, null, null);
	}

	return SUCCESS;
    }

    /**
     * Fill the lookup vault data filtered by the defined criteria
     * 
     * @return
     */
    public String populateATMInterfacesLookup()
    {
	try
	{
	    setSearchFilter(atmInterfaceSC);
	    copyproperties(atmInterfaceSC);
	    SessionCO sessionCO = returnSessionObject();
	    atmInterfaceSC.setStatus(ATMCommonConstants.STATUS_APPROVED);
	    atmInterfaceSC.setNbRec(-1);
	    atmInterfaceSC.setCompCode(sessionCO.getCompanyCode());
	    atmInterfaceSC.setCurrAppName(sessionCO.getCurrentAppName());
	    atmInterfaceSC.setPreferredLanguage(sessionCO.getLanguage());
	    atmInterfaceSC.setInterfaceTypeLovId(AtmInterfaceConstants.INTERFACE_TYPE);
	    atmInterfaceSC.setLovTypeId(ATMCommonConstants.COMMON_STATUS_LOV);
	    atmInterfaceSC.setCrudMode(getIv_crud());
	    atmInterfaceSC.setPageRef(get_pageRef());
	    List<AtmInterfaceCO> atmInterfaceCOs = atmInterfaceBO.returnInterfaceList(atmInterfaceSC);
	    setGridModel(atmInterfaceCOs);
	}
	catch(Exception e)
	{
	    e.printStackTrace();
	    log.error(e, "Error in fillLookupData of ATMInterfacesLookupAction");
	    handleException(e, null, null);
	}
	return SUCCESS;
    }

    @Override
    public Object getModel()
    {
	return atmInterfaceSC;
    }

    public AtmInterfaceSC getAtmInterfaceSC()
    {
        return atmInterfaceSC;
    }

    public void setAtmInterfaceSC(AtmInterfaceSC atmInterfaceSC)
    {
        this.atmInterfaceSC = atmInterfaceSC;
    }

    public void setAtmInterfaceBO(AtmInterfaceBO atmInterfaceBO)
    {
        this.atmInterfaceBO = atmInterfaceBO;
    }

}