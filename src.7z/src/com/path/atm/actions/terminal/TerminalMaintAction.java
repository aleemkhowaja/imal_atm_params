package com.path.atm.actions.terminal;

import java.util.ArrayList;
import java.util.List;

import com.path.atm.actions.common.base.ATMBaseAction;
import com.path.atm.bo.common.ATMCommonConstants;
import com.path.atm.bo.terminal.TerminalBO;
import com.path.atm.bo.terminal.TerminalConstant;
import com.path.atm.vo.terminal.TerminalCO;
import com.path.atm.vo.terminal.TerminalSC;
import com.path.bo.common.ConstantsCommon;
import com.path.bo.common.audit.AuditConstant;
import com.path.expression.common.PBFunc.BaseException;
import com.path.lib.common.util.NumberUtil;
import com.path.vo.common.SessionCO;
import com.path.vo.common.audit.AuditRefCO;
import com.path.vo.common.select.SelectCO;
import com.path.vo.common.select.SelectSC;

/**
 * 
 * Copyright 2019, Path Solutions
 * Path Solutions retains all ownership rights to this source code 
 * 
 * @author: Alim Khowaja
 *
 * TerminalMaintAction.java used to
 */
public class TerminalMaintAction extends ATMBaseAction
{	
    private TerminalBO terminalBO;
    private TerminalCO terminalCO = new TerminalCO();
    private TerminalSC criteria = new TerminalSC();
    private List<SelectCO> terminalTypeList;

    /**
     * return Channel Page
     * 
     * @return
     */
    public String loadPage()
    {
	try
	{
	    set_searchGridId("terminalListGridTbl_Id");
	    set_showNewInfoBtn("true");
	    set_showSmartInfoBtn("false");

	    // fill session data
	    fillSessionData();

	    // fill dropdown data
	    fillDropDown();

	    terminalCO.setStatusDesc(getText(ATMCommonConstants.ACTIVE));
	    // set Color in Status Description
	    terminalCO.setStatusColorCode(getStatusColorCode(ATMCommonConstants.STATUS_ACTIVE,
		    ATMCommonConstants.STATUS_COLOR_CODE_B));

	    // set disable/set readonly fields
//	    terminalCO = terminalBO.applySysParamSettings(terminalCO);
//	    setAdditionalScreenParams(terminalCO.getElementMap());
	}
	catch(Exception ex)
	{
	    handleException(ex, null, null);
	}
	return "terminallList";
    }

    /**
     * Save Channel Record
     * 
     * @return
     */
    public String save()
    {
	try
	{
	    fillSessionData();
	    AuditRefCO refCO = null;

	    if(ConstantsCommon.YES.equals(terminalCO.getUpdateMode()))
	    {
		refCO = fillAuditDetails(AuditConstant.UPDATE);
		terminalCO.setAuditObj(returnAuditObject(terminalCO.getClass()));
	    }
	    else
	    {
		refCO = fillAuditDetails(AuditConstant.CREATED);
	    }
	    terminalCO.setAuditRefCO(refCO);
	    // save Channel Record
	    terminalCO = terminalBO.save(terminalCO);
	}
	catch(Exception e)
	{
	    handleException(e, null, null);
	}
	return SUCCESS;

    }

    /**
     * return Channel Record by id
     * 
     * @return
     */
    public String edit()
    {
	try
	{
	    // fill session data
	    fillSessionData();

	    // fill dropdown
	    fillDropDown();

	    // retrieve record
	    terminalCO = terminalBO.edit(criteria);
	    terminalCO.getGtw_ATM_TERMINALVO().setCOMP_CODE(criteria.getCompCode());
	    terminalCO.setUpdateMode(ConstantsCommon.YES);
	    
	    //apply retrieve audit
	    applyRetrieveAudit(AuditConstant.atmTerminalKey , terminalCO.getGtw_ATM_TERMINALVO(), terminalCO);
	    
	    // set disable/set readonly fields
	   // setAdditionalScreenParams(terminalBO.applySysParamSettings(terminalCO).getElementMap());

	}
	catch(

	Exception e)
	{
	    handleException(e, null, null);
	    return ERROR;
	}
	return "terminalMaint";
    }

    /**
     * Delete Channel Record
     * 
     * @return
     */
    public String delete()
    {
	try
	{
	    // apply session value
	    fillSessionData();
	    // delete record
	    terminalBO.delete(terminalCO);
	}
	catch(Exception e)
	{
	    handleException(e, null, null);
	}
	return SUCCESS;
    }

    /**
     * clear the Form
     */
    public String clear()
    {
	try
	{
	    terminalCO = new TerminalCO();

	    fillSessionData();
	    // set disable/set readonly fields
	 //   setAdditionalScreenParams(terminalBO.applySysParamSettings(terminalCO).getElementMap());
	    fillDropDown();
	}
	catch(Exception e)
	{
	    handleException(e, null, null);
	}
	return "terminalMaint";
    }

    /**
     * Fill Dropdown
     */
    private void fillDropDown()
    {
	try
	{
	    SessionCO sessionCO = returnSessionObject();

	    terminalTypeList = new ArrayList<SelectCO>();
	    // retrieve communication protocol
	    SelectSC selSC = new SelectSC(TerminalConstant.TERMINAL_TYPE_LOV);
	    selSC.setLanguage(sessionCO.getLanguage());
	    selSC.setOrderCriteria("ORDER");
	    terminalTypeList = returnLOV(selSC);
	}
	catch(Exception ex)
	{
	    handleException(ex, null, null);
	}
    }

    /**
     * Fill Session
     * 
     * @throws BaseException
     */
    public void fillSessionData() throws BaseException
    {
	SessionCO sessionCO = returnSessionObject();
	terminalCO.setCompCode(sessionCO.getCompanyCode());
	terminalCO.setBranchCode(sessionCO.getBranchCode());
	terminalCO.setAppName(sessionCO.getCurrentAppName());
	terminalCO.setProgRef(get_pageRef());
	terminalCO.setUserID(sessionCO.getUserName());
	terminalCO.setLanguage(sessionCO.getLanguage());
	terminalCO.setUserID(sessionCO.getUserName());
	criteria.setCompCode(terminalCO.getCompCode());
	terminalCO.getGtw_ATM_TERMINALVO().setCOMP_CODE(terminalCO.getCompCode());
	try
	{
	    terminalCO.setRunningDate(returnCommonLibBO().addSystemTimeToDate(sessionCO.getRunningDateRET()));
	}
	catch(com.path.lib.common.exception.BaseException e)
	{
	    handleException(e, null, null);
	}
    }
    
    /**
     * Validate Termianl
     * 
     * @return
     * @throws BaseException
     */
    public String validateTerminalId() throws BaseException
    {
	try
	{
	    terminalCO = terminalBO.validateTerminalId(terminalCO);
	    NumberUtil.resetEmptyValues(terminalCO);
	}
	catch(Exception e)
	{
	    terminalCO.getGtw_ATM_TERMINALVO().setTERMINAL_CODE("");
	    handleException(e, null, null);
	}
	return SUCCESS;
    }

    /**
     * Fill Audit Details
     * 
     * @param status
     * @return
     */
    private AuditRefCO fillAuditDetails(String status)
    {
	AuditRefCO refCO = initAuditRefCO();
	try
	{
	    refCO.setOperationType(status);
	    refCO.setKeyRef(AuditConstant.atmTerminalKey);
	    refCO.setRunningDate(terminalCO.getRunningDate());
	}
	catch(Exception e)
	{
	    handleException(e, null, null);
	}
	return refCO;
    }

    public void setTerminalBO(TerminalBO terminalBO)
    {
	this.terminalBO = terminalBO;
    }

    public TerminalCO getTerminalCO()
    {
	return terminalCO;
    }

    public void setTerminalCO(TerminalCO terminalCO)
    {
	this.terminalCO = terminalCO;
    }

    public TerminalSC getCriteria()
    {
	return criteria;
    }

    public void setCriteria(TerminalSC criteria)
    {
	this.criteria = criteria;
    }

    public List<SelectCO> getTerminalTypeList()
    {
	return terminalTypeList;
    }

    public void setTerminalTypeList(List<SelectCO> terminalTypeList)
    {
	this.terminalTypeList = terminalTypeList;
    }

}
