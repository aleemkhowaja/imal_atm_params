package com.path.atm.actions.common.base;

import com.path.atm.bo.common.ATMCommonConstants;
import com.path.atm.vo.common.ATMBaseCO;
import com.path.struts2.lib.common.base.BaseAction;

/**
 * 
 * Copyright 2019, Path Solutions
 * Path Solutions retains all ownership rights to this source code 
 * 
 * @author: Alim Khowaja
 *
 * ATMBaseAction.java used to
 */
public class ATMBaseAction extends BaseAction
{
    private ATMBaseCO atmBaseCO = new ATMBaseCO();
    /**
     * Returns the RGB color for status code
     *
     * @param status
     */
    protected String getStatusColorCode(String status, String space)
    {
	String colorCode = "";

	if("A".equals(status)) // Active
	{
	    colorCode = ATMCommonConstants.STATUS_COLOR_CODE_B.equals(space) ? "RGB(000,128,000)" : "RGB(255,255,255)";// GREEN
	}
	else if("P".equals(status)) // Approved
	{
	    colorCode = ATMCommonConstants.STATUS_COLOR_CODE_B.equals(space) ? "RGB(000,000,255)" : "RGB(255,255,255)"; // BLUE
	}
	else if("CR".equals(status)) // Create new record in maintance screen 
	{
	    colorCode = ATMCommonConstants.STATUS_COLOR_CODE_B.equals(space) ? "RGB(31,73,125)"
		    : "RGB(255,255,255)"; // BLUE
	}
	else // Deleted,Reversed
	{
	    colorCode = ATMCommonConstants.STATUS_COLOR_CODE_B.equals(space) ? "RGB(255,000,000)" : "RGB(255,255,255)";
	}
	return colorCode;

    }

    /**
     * load Dialog Page
     */
    public String returnDialogPage()
    {
	return atmBaseCO.getPageResult();
    }


    public ATMBaseCO getAtmBaseCO()
    {
	return atmBaseCO;
    }

    public void setAtmBaseCO(ATMBaseCO atmBaseCO)
    {
	this.atmBaseCO = atmBaseCO;
    }

}
