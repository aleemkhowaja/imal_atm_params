package com.path.atm.actions.merchantmgnt.lookups;

import java.math.BigDecimal;

import org.apache.struts2.json.JSONException;

import com.path.atm.bo.merchantmgnt.MerchantMgntBO;
import com.path.atm.vo.merchantmgnt.MerchantMgntCO;
import com.path.atm.vo.merchantmgnt.MerchantMgntSC;
import com.path.lib.common.util.StringUtil;
import com.path.struts2.lib.common.base.LookupBaseAction;
import com.path.vo.common.SessionCO;

public class AccountReferenceDependencyAction extends LookupBaseAction
{
    private MerchantMgntSC criteria;
    private MerchantMgntCO merchantMgntCO;
    private MerchantMgntBO merchantMgntBO;

    public String returnAccountReferenceByCode() throws JSONException
    {
	try
	{
	    if(StringUtil.isNotEmpty(criteria.getAdditionalRef()))
	    {
		SessionCO sessionCO = returnSessionObject();
		criteria.setCompCode(sessionCO.getCompanyCode());
		criteria.setLang(sessionCO.getLanguage());
		criteria.setDependencyType("AccountRef");
		criteria.setIBAN("");

		merchantMgntCO = new MerchantMgntCO();
		merchantMgntCO.getGtwAtmMerchantVO().setADDITIONAL_REFERENCE(criteria.getAdditionalRef());
		// temporary disable web service call
		// merchantMgntCO.setMerchantAccountName(merchantMgntBO.returnMerchantName(criteria));
		// disable IBAN text filed
		merchantMgntCO.setLookupName("IBAN");
		merchantMgntCO = merchantMgntBO.applySysParamSettings(merchantMgntCO, BigDecimal.ONE);
		setAdditionalScreenParams(merchantMgntCO.getElementMap());
	    }
	    else
	    {
		merchantMgntCO = new MerchantMgntCO();
		// temporary disable web service call
//		merchantMgntCO.setMerchantAccountName("");
		// enable IBAN text filed
		merchantMgntCO.setLookupName("IBAN");
		merchantMgntCO = merchantMgntBO.applySysParamSettings(merchantMgntCO, BigDecimal.ZERO);
		setAdditionalScreenParams(merchantMgntCO.getElementMap());
	    }
	}
	catch(Exception e)
	{
	    e.printStackTrace();
	    handleException(e, null, null);
	}
	return SUCCESS;
    }

    public MerchantMgntSC getCriteria()
    {
	return criteria;
    }

    public void setCriteria(MerchantMgntSC criteria)
    {
	this.criteria = criteria;
    }

    public MerchantMgntCO getMerchantMgntCO()
    {
	return merchantMgntCO;
    }

    public void setMerchantMgntCO(MerchantMgntCO merchantMgntCO)
    {
	this.merchantMgntCO = merchantMgntCO;
    }

    public MerchantMgntBO getMerchantMgntBO()
    {
	return merchantMgntBO;
    }

    public void setMerchantMgntBO(MerchantMgntBO merchantMgntBO)
    {
	this.merchantMgntBO = merchantMgntBO;
    }

}
