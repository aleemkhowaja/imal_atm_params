package com.path.atm.actions.merchantmgnt.lookups;

import java.math.BigDecimal;

import com.path.atm.actions.common.base.ATMBaseAction;
import com.path.atm.bo.merchantmgnt.MerchantMgntBO;
import com.path.atm.vo.merchantmgnt.MerchantMgntCO;
import com.path.atm.vo.merchantmgnt.MerchantMgntSC;
import com.path.lib.common.util.StringUtil;
import com.path.vo.common.SessionCO;

public class IBANDependencyAction extends ATMBaseAction
{
    private MerchantMgntSC criteria = new MerchantMgntSC();
    private MerchantMgntCO merchantMgntCO = new MerchantMgntCO();
    private MerchantMgntBO merchantMgntBO;

    
    @Override
    public Object getModel()
    {
        return merchantMgntCO;
    }
    
    public String returnIBANByCode() 
    {
	try
	{
	    if(StringUtil.isNotEmpty(criteria.getIBAN()))
	    {
		SessionCO sessionCO = returnSessionObject();

		criteria.setCompCode(sessionCO.getCompanyCode());
		criteria.setLang(sessionCO.getLanguage());
		criteria.setDependencyType("IBAN");
		criteria.setAdditionalRef("");

		merchantMgntCO = new MerchantMgntCO();
		merchantMgntCO.getGtwAtmMerchantVO().setIBAN_ACC_NO(criteria.getIBAN());
		// temporary disable web service call
		//merchantMgntCO.setMerchantAccountName(merchantMgntBO.returnMerchantName(criteria));
		// disable acc_additional_ref text filed
		merchantMgntCO.setLookupName("acc_additional_ref");
		merchantMgntCO = merchantMgntBO.applySysParamSettings(merchantMgntCO, BigDecimal.ONE);
		setAdditionalScreenParams(merchantMgntCO.getElementMap());
	    }
	    else
	    {
		merchantMgntCO = new MerchantMgntCO();
		// temporary disable web service call
		// merchantMgntCO.setMerchantAccountName("");
		// Enable acc_additional_ref text filed
		merchantMgntCO.setLookupName("acc_additional_ref");
		merchantMgntCO = merchantMgntBO.applySysParamSettings(merchantMgntCO, BigDecimal.ZERO);
		setAdditionalScreenParams(merchantMgntCO.getElementMap());
	    }
	}
	catch(Exception e)
	{
	    handleException(e, null, null);
	}
	return SUCCESS;
    }
    
    public MerchantMgntSC getCriteria()
    {
	return criteria;
    }

    public void setCriteria(MerchantMgntSC criteria)
    {
	this.criteria = criteria;
    }

    public MerchantMgntCO getMerchantMgntCO()
    {
	return merchantMgntCO;
    }

    public void setMerchantMgntCO(MerchantMgntCO merchantMgntCO)
    {
	this.merchantMgntCO = merchantMgntCO;
    }

    public void setMerchantMgntBO(MerchantMgntBO merchantMgntBO)
    {
	this.merchantMgntBO = merchantMgntBO;
    }

}
